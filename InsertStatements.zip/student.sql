insert into 
student (student_id,student_firstname,student_lastname,student_gender,student_dob,student_phoneno,
student_emailid,student_address,login_login_id) 
values('110011','bhanu','kodam','female','1996-09-06','9440072189','bhanu@hotmail.com','2 Packard blvd scarborough',
'101');
insert into 
student (student_id,student_firstname,student_lastname,student_gender,student_dob,student_phoneno,
student_emailid,student_address,login_login_id) 
values('110022','syroosha','manne','female','1996-05-01','9440072190','manne@hotmail.com','92 gibson drive scarborough',
'102');
insert into 
student (student_id,student_firstname,student_lastname,student_gender,student_dob,student_phoneno,
student_emailid,student_address,login_login_id) 
values('110033','dinesh','sheela','male','02/05/1996','9440072191','dinesh@hotmail.com','89heathrow drive scarborough',
'103');