
insert into login(login_id, login_username, login_password)  values('103','smannebeacon','Passw0rd');
insert into login(login_id, login_username, login_password)  values('102','dsheelabeacon','Passw0rd');
insert into login(login_id, login_username, login_password)  values('101','bkodambeacon','Passw0rd');