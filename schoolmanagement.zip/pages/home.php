<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
} 
   
    include('../config/DbFunction.php');
    $obj=new DbFunction();
	$rs=$obj->showCourse();


	if(isset($_GET['del']))
    {
           
          $obj->del_course(intval($_GET['del']));
          
       
  }

?> 

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>view course</title>
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="homestyle.css">
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
      
     <?php include('leftbar.php')?>

           
         <nav>
        <div id="page-wrapper">
            <section>
            <div class="row">
                <div class="col-lg-12">
                   <h4 class="page-header"> <?php echo strtoupper("welcome"." ".htmlentities($_SESSION['login']));?></h4>
                </div>
                <!-- /.col-lg-12 -->
            </div>
                </section>
                        <section>
        <div class="container">
            <div class="grid">
                <div class="left">
                    <img src=../img/about.jpg alt="">
                </div>
                <div class="right">
                    <div class="col-lg-10">
                    
                    <h1>Admin</h1>
                    <h3>Announcement</h3>
                    <p>Faculty and students are responsible for ensuring that all material uploaded, copied, displayed and communicated through eConestoga is in compliance with the Canadian Copyright Act and Fair Dealing. To learn more about copyright, review the Library Services’ copyright guides for Faculty and Staff and Students.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>   
        
    <div class="services">
      <h1>News</h1>
      <div class="cen">
        <div class="service">
        
          <h2>Employee milestones celebrated</h2>
          <p>On March 10, the Beacon community recognized employee milestone anniversaries reached in 2019 and 2020 at two virtual Guild Receptions.</p>
        </div>

        <div class="service">
        
          <h2>Beacon celebrates International Women's Day</h2>
          <p>The Beacon community gathered virtually on March 5 to celebrate International Women's Day </p>
        </div>

        <div class="service">
          
          <h2>Flags at half-mast on March 11</h2>
          <p>Flags at all Beacon campuses will be flown at half-mast today in recognition of the National Day of Observance to commemorate the lives.</p>
        </div>       
      </div>
    </div>
           
            
           
        </div>
        <!-- /#page-wrapper -->


             </div>
             <?php include('footer.php')?>

    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>

</html>