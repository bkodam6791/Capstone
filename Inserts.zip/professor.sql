insert into professor(professor_id,professor_firstname,professor_lastname,professor_email,
professor_phoneno,professor_gender) values
('220011','Lubna','Naqvi','lnaqvi@hotmail.com','9440011220','female');
insert into professor(professor_id,professor_firstname,professor_lastname,professor_email,
professor_phoneno,professor_gender) values
('220022','Asad','baig','abaig@hotmail.com','9440011221','male');
insert into professor(professor_id,professor_firstname,professor_lastname,professor_email,
professor_phoneno,professor_gender) values
('220033','Angela','Martins','Amartins@hotmail.com','9440011222','female');
insert into professor(professor_id,professor_firstname,professor_lastname,professor_email,
professor_phoneno,professor_gender) values
('220044','Simon','Mark','smark@hotmail.com','9440011223','male');
insert into professor(professor_id,professor_firstname,professor_lastname,professor_email,
professor_phoneno,professor_gender) values
('220055','jaspreet','kaur','jkaur@hotmail.com','9440011224','female');

select * from professor;