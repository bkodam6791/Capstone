insert into program (program_id,program_name,program_length,program_delivery) values
('8000','Web Design', '4 months', 'Classroom');
insert into program (program_id,program_name,program_length,program_delivery) values
('8011','Business Analytics', '4 months', 'Remote');
insert into program (program_id,program_name,program_length,program_delivery) values
('8022','Machine Learning', '4 months', 'Classroom');
insert into program (program_id,program_name,program_length,program_delivery) values
('8033','Artificial Intelligence', '4 months', 'Remote');
insert into program (program_id,program_name,program_length,program_delivery) values
('8044','Project Management', '4 months', 'Classroom');
insert into program (program_id,program_name,program_length,program_delivery) values
('8055','Business Management', '4 months', 'Remote');

select * from program;