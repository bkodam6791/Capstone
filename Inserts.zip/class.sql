insert into class (class_id, class_name) values ('301',' Web Traffic');
insert into class (class_id, class_name) values ('302',' Responsive Design');
insert into class (class_id, class_name) values ('303',' Photoshop');
insert into class (class_id, class_name) values ('304',' Android Development');


select * from class;