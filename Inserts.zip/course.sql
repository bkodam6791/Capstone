insert into course(course_id, course_name,professor_professor_id,program_program_id) values
('8000101','php','220011','8000');
insert into course(course_id, course_name,professor_professor_id,program_program_id) values
('8000102','sql','220022','8011');
insert into course(course_id, course_name,professor_professor_id,program_program_id) values
('8000103','html','220033','8022');
insert into course(course_id, course_name,professor_professor_id,program_program_id) values
('8000104','angularjs','220044','8033');
insert into course(course_id, course_name,professor_professor_id,program_program_id) values
('8000105','javascript','220055','8044');


how are program and course different from each other

