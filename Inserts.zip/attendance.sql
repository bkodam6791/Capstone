insert into attendance(attendance_id,attendance_date,attendance_status,
student_has_class_student_student_id,student_has_class_class_class_id) values 
('9000 ','2021-02-03', 'Regular','110011 ','301 ');
insert into attendance(attendance_id,attendance_date,attendance_status,
student_has_class_student_student_id,student_has_class_class_class_id) values 
('9001 ','2021-02-03', 'Regular','110022 ','302 ');
insert into attendance(attendance_id,attendance_date,attendance_status,
student_has_class_student_student_id,student_has_class_class_class_id) values 
('9002 ','2021-02-03', 'Regular','110033 ','303 ');



select * from attendance;
 
