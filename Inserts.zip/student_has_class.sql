insert into student_has_class(student_student_id,class_class_id,course_course_id) values('110011','301',' ');
insert into student_has_class(student_student_id,class_class_id,course_course_id) values('110022','302',' ');
insert into student_has_class(student_student_id,class_class_id,course_course_id) values('110033','303',' ');
insert into student_has_class(student_student_id,class_class_id,course_course_id) values('110044','304',' ');
insert into student_has_class(student_student_id,class_class_id,course_course_id) values('110055','305',' ');

select * from student_has_class;